public class WrongAge extends Exception {
    public WrongAge(String message) {
        super(message);
    }
}