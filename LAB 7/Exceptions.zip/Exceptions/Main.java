import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int n=1;
	while(n!=0){
	        try {
		   System.out.println("father age : ");
		   int fatherage = sc.nextInt();
 	           Father father = new Father(fatherage);
 	           System.out.println("Father's age: " + father.getFatherAge());
		   System.out.println("son age : ");
 	           int sonage = sc.nextInt();
	            Son son = new Son(fatherage, sonage);
	            System.out.println("Son's age: " + son.getSonAge());
	
	        } catch (WrongAge e) {
	            System.out.println("Exception: " + e.getMessage());
	        }
		System.out.println("Enter 0 to exit ");
		n = sc.nextInt();
	}
    }
}