public class Father {
    protected int fatherAge;

    // Constructor for Father class
    public Father(int fatherAge) throws WrongAge {
        if (fatherAge < 0) {
            throw new WrongAge("Father's age cannot be negative.");
        }
        this.fatherAge = fatherAge;
    }

    public int getFatherAge() {
        return fatherAge;
    }
}